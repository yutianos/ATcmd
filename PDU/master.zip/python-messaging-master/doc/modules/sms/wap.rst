:mod:`messaging.sms.wap`
========================

.. automodule:: messaging.sms.wap

Functions
---------

.. autofunction:: is_a_wap_push_notification

.. autofunction:: extract_push_notification
