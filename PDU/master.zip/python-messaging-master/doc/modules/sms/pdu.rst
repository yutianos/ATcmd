:mod:`messaging.sms.pdu`
==========================

.. automodule:: messaging.sms.pdu

Classes
--------

.. autoclass:: Pdu
   :members:
