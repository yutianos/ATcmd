:mod:`messaging.sms.submit`
===========================

.. automodule:: messaging.sms.submit

Classes
--------

.. autoclass:: SmsSubmit
   :show-inheritance:
   :members:
