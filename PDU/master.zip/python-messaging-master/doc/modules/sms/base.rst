:mod:`messaging.sms.base`
=========================

.. automodule:: messaging.sms.base

Classes
--------

.. autoclass:: SmsBase
   :members:
