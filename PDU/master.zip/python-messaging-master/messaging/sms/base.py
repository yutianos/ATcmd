# see LICENSE


class SmsBase(object):

    def __init__(self):
        self.udh = None
        self.number = None
        self.text = None
        self.fmt = None
        self.dcs = None
        self.pid = None
        self.csca = None
        self.type = None
